import numpy as np


def Model(X, z=None):
    """
    Coulomb Counting SOC Estimator - Python version

    Parameters
    ----------
    X : array-like
        Measured [Current, Voltage, Temperature]
    z : float, optional
        Previous SOC state

    Returns
    -------
    Y_est : float
        Estimated SOC
    z : float
        Updated SOC state
    """

    X = np.asarray(X, dtype=float).reshape(-1)

    # Current is negative-discharging, positive-charging
    Current = X[0]

    # Voltage unused
    # Voltage = X[1]

    # Temperature unused
    # Temperature = X[2]

    Capacity = 4.55  # Ah

    # Coulomb counting
    if z is None:
        SOC = 0.995
        z = SOC
    else:
        previous_SOC = z
        SOC = previous_SOC + Current * (1.0 / 3600.0) / Capacity
        z = SOC

    Y_est = float(SOC)
    return Y_est, z