import numpy as np
from scipy.io import loadmat
from pathlib import Path


def _mat_to_dict(obj):
    """
    Recursively convert scipy matlab structs into Python dicts.
    """
    if hasattr(obj, "_fieldnames"):
        return {name: _mat_to_dict(getattr(obj, name)) for name in obj._fieldnames}

    if isinstance(obj, np.ndarray):
        if obj.dtype == object:
            if obj.size == 1:
                return _mat_to_dict(obj.item())
            return [_mat_to_dict(x) for x in obj.flat]
        return obj

    return obj


def _interp1(x, y, xi):
    """
    MATLAB-like 1D linear interpolation with extrapolation.
    """
    x = np.asarray(x, dtype=float).reshape(-1)
    y = np.asarray(y, dtype=float).reshape(-1)
    xi = float(xi)

    order = np.argsort(x)
    x = x[order]
    y = y[order]

    if xi <= x[0]:
        if len(x) < 2:
            return float(y[0])
        slope = (y[1] - y[0]) / (x[1] - x[0])
        return float(y[0] + slope * (xi - x[0]))

    if xi >= x[-1]:
        if len(x) < 2:
            return float(y[-1])
        slope = (y[-1] - y[-2]) / (x[-1] - x[-2])
        return float(y[-1] + slope * (xi - x[-1]))

    return float(np.interp(xi, x, y))


def _load_cached_data():
    """
    Load parameter files once per process, from the same folder as model.py
    """
    if not hasattr(_load_cached_data, "_cache"):
        base_dir = Path(__file__).resolve().parent

        ecm_raw = loadmat(base_dir / "ECM_parameters.mat", struct_as_record=False, squeeze_me=True)
        ocv_raw = loadmat(base_dir / "OCV_table.mat", struct_as_record=False, squeeze_me=True)
        ekf_raw = loadmat(base_dir / "EKF_parameters.mat", struct_as_record=False, squeeze_me=True)

        ECM = _mat_to_dict(ecm_raw["ECM"])
        EKF = _mat_to_dict(ekf_raw["EKF"])
        OCV_table = np.asarray(ocv_raw["OCV_table"], dtype=float)
        SOC_range = np.asarray(ocv_raw["SOC_range"], dtype=float).reshape(-1)

        _load_cached_data._cache = {
            "ECM": ECM,
            "EKF": EKF,
            "OCV_table": OCV_table,
            "SOC_range": SOC_range,
        }

    return _load_cached_data._cache


def _pick_temperature_branch(temp_c, ECM, EKF):
    if temp_c > 30:
        return ECM["T40"], EKF["T40"], 5
    elif temp_c > 17.5:
        return ECM["T25"], EKF["T25"], 4
    elif temp_c > 5:
        return ECM["T10"], EKF["T10"], 3
    elif temp_c > -5:
        return ECM["T0"], EKF["T0"], 2
    elif temp_c > -15:
        return ECM["Tn10"], EKF["Tn10"], 1
    else:
        return ECM["Tn20"], EKF["Tn20"], 0


def _param_interp(param_struct, field_name, soc):
    return _interp1(param_struct["SOC"], param_struct[field_name], soc)


def Model(X, z=None):
    """
    Python conversion of the MATLAB EKF-based Model.m

    Input:
        X = [Current, Voltage, Temperature]
        z = state memory dict

    Output:
        SOC_Pred, z
    """
    X = np.asarray(X, dtype=float).reshape(-1)

    I = -float(X[0])
    V = float(X[1])
    T_meas = float(X[2])

    if z is None:
        data = _load_cached_data()
        ECM = data["ECM"]
        EKF = data["EKF"]
        OCV_table = data["OCV_table"]
        SOC_range = data["SOC_range"]

        param_branch, ekf_branch, T_idx = _pick_temperature_branch(T_meas, ECM, EKF)

        z = {}
        z["Param"] = param_branch
        z["EKF"] = ekf_branch
        z["OCV_SOC"] = np.asarray(OCV_table[T_idx, :], dtype=float).reshape(-1)
        z["SOC_range"] = SOC_range

        init_SOC = _interp1(z["OCV_SOC"], SOC_range, V)
        init_SOC = float(np.clip(init_SOC, 0.0, 1.0))

        z["C0"] = 4.68
        z["R0"] = _param_interp(z["Param"], "R0", init_SOC)
        z["R1"] = _param_interp(z["Param"], "R1", init_SOC)
        z["R2"] = _param_interp(z["Param"], "R2", init_SOC)
        z["R3"] = _param_interp(z["Param"], "R3", init_SOC)
        z["C1"] = _param_interp(z["Param"], "T1", init_SOC) / z["R1"]
        z["C2"] = _param_interp(z["Param"], "T2", init_SOC) / z["R2"]
        z["C3"] = _param_interp(z["Param"], "T3", init_SOC) / z["R3"]

        z["Param"]["SOC_now"] = init_SOC

        P = np.diag([0.05, 0.05, 0.05, 0.001]).astype(float)
        x = np.array([0.0, 0.0, 0.0, init_SOC], dtype=float)

    else:
        P = np.asarray(z["P"], dtype=float)
        x = np.asarray(z["x"], dtype=float)

    R = float(np.asarray(z["EKF"]["R"], dtype=float).squeeze())
    Q = np.asarray(z["EKF"]["Q"], dtype=float)

    a1 = np.exp(-1.0 / (z["C1"] * z["R1"]))
    a2 = np.exp(-1.0 / (z["C2"] * z["R2"]))
    a3 = np.exp(-1.0 / (z["C3"] * z["R3"]))

    x_hat = np.array([
        a1 * x[0] + ((1.0 - np.exp(-1.0 / (z["R1"] * z["C1"]))) * z["R1"]) * I,
        a2 * x[1] + ((1.0 - np.exp(-1.0 / (z["R2"] * z["C2"]))) * z["R2"]) * I,
        a3 * x[2] + ((1.0 - np.exp(-1.0 / (z["R3"] * z["C3"]))) * z["R3"]) * I,
        x[3] - (1.0 / (3600.0 * z["C0"])) * I,
    ], dtype=float)

    F = np.array([
        [a1, 0.0, 0.0, 0.0],
        [0.0, a2, 0.0, 0.0],
        [0.0, 0.0, a3, 0.0],
        [0.0, 0.0, 0.0, 0.0],
    ], dtype=float)

    ocv_soc = np.asarray(z["OCV_SOC"], dtype=float).reshape(-1)
    soc_range = np.asarray(z["SOC_range"], dtype=float).reshape(-1)

    dOCV_dSOC = np.zeros_like(ocv_soc, dtype=float)
    n = len(ocv_soc)

    for i in range(1, n - 1):
        dOCV_dSOC[i] = (ocv_soc[i + 1] - ocv_soc[i - 1]) / (soc_range[i + 1] - soc_range[i - 1])

    dOCV_dSOC[0] = (ocv_soc[1] - ocv_soc[0]) / (soc_range[1] - soc_range[0])
    dOCV_dSOC[-1] = (ocv_soc[-1] - ocv_soc[-2]) / (soc_range[-1] - soc_range[-2])

    H = np.array([
        -1.0,
        -1.0,
        -1.0,
        _interp1(soc_range, dOCV_dSOC, x[3]),
    ], dtype=float).reshape(1, 4)

    P = F @ P @ F.T + Q

    y_hat = _interp1(soc_range, ocv_soc, x_hat[3]) - x_hat[0] - x_hat[1] - x_hat[2]
    error = V - y_hat

    S = H @ P @ H.T + R
    K = P @ H.T @ np.linalg.inv(S)

    x_pred = x_hat + (K.flatten() * error)
    P = (np.eye(4) - K @ H) @ P

    SOC_Pred = float(x_pred[3])

    z["P"] = P
    z["x"] = x_pred

    if abs(SOC_Pred - z["Param"]["SOC_now"]) > 0.02:
        z["R0"] = _param_interp(z["Param"], "R0", SOC_Pred)
        z["R1"] = _param_interp(z["Param"], "R1", SOC_Pred)
        z["R2"] = _param_interp(z["Param"], "R2", SOC_Pred)
        z["R3"] = _param_interp(z["Param"], "R3", SOC_Pred)
        z["C1"] = _param_interp(z["Param"], "T1", SOC_Pred) / z["R1"]
        z["C2"] = _param_interp(z["Param"], "T2", SOC_Pred) / z["R2"]
        z["C3"] = _param_interp(z["Param"], "T3", SOC_Pred) / z["R3"]
        z["Param"]["SOC_now"] = SOC_Pred

    return SOC_Pred, z