function [Y_est, z] = Model(X, z, dt)
    % Set defaults if inputs are missing
    if nargin < 1 || isempty(X)
        X = [0, 0, 25];  % Default: 0 A current, 0 V, 25°C
    end
    if nargin < 2
        z = [];
    end
    if nargin < 3
        dt = 1;  % Default 1 second
    end

    % Extract current
    Current = X(1);  % [A]

    % Nominal capacity
    Capacity = 4.6;  % [Ah]

    % Initialize SOC if first call or z is empty
    if isempty(z)
        SOC = 1;  % Fully charged at start
    else
        % Coulomb counting update
        SOC = z + (Current * dt / 3600) / Capacity;
        SOC = max(0, min(1, SOC));  % Clamp SOC
    end

    % Update memory
    z = SOC;

    % Output estimated SOC
    Y_est = SOC;
end


