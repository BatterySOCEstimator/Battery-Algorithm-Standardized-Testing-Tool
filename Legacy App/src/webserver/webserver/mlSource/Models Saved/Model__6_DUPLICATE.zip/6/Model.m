% Online Coulomb Counting SOC Estimator - McMaster University 2024
function [Y_est, z] = Model(X, z)
    % Input X: Measured current, voltage, and temperature values
    % X: 3 columns, 1 row
    
    % Current is negative-discharging, positive-charging
    Current = X(1);             % in [Amps]
    
    % Voltage is unused in this Coulomb Counter
    % Voltage = X(2);             % in [Volts]
    
    % Temperature is unused in this Coulomb Counter
    % Temperature = X(3);         % in [Celsius]
    
    Capacity = 4.6;             % in [Ah], Nominal capacity of new Tesla 21700 NMC/NCA cell
    
    % Coulomb Counting SOC Estimator: SOC = integral of current
    if nargin == 1              % If this is at the start of measurement (z = [])
        SOC = 1;                % Assume battery always starts fully charged
        z = SOC;                % Send back previous SOC as memory z
    else
        previous_SOC = z;       % Load z as previous SOC
        SOC = previous_SOC + Current*(1/3600)/Capacity; % Update SOC by integrating current
        z = SOC;                % Send back previous SOC as memory z
    end
    
    % Output Y: Estimated SOC
    % Y: 1 columns, 1 row
    Y_est=SOC'; %Transpose SOC from columns to rows  
end