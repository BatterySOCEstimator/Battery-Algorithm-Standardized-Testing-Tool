% Online Coulomb Counting SOC Estimator with Efficiency Loss - McMaster University 2024
function [Y_est, z] = Model(X, z)
    % Input X: Measured current, voltage, and temperature values
    % X: 3 columns, 1 row
    
    % Current is negative = discharging, positive = charging
    Current = X(1);             % in [Amps]
    
    % Voltage and Temperature unused in this version
    % Voltage = X(2);           
    % Temperature = X(3);       
    
    Capacity = 4.6;             % in [Ah], Nominal capacity of new Tesla 21700 NMC/NCA cell
    
    % Coulombic efficiency factor (different for charging/discharging)
    eta_charge = 0.995;         % < 100% efficiency during charging
    eta_discharge = 1.0;        % assume no extra loss for discharging
    
    % Coulomb Counting SOC Estimator
    if nargin == 1              % Start of measurement (z = [])
        SOC = 1;                % Battery assumed fully charged at start
        z = SOC;                % Store SOC in memory
    else
        previous_SOC = z;       % Load z as previous SOC
        
        if Current >= 0
            % Charging with efficiency penalty
            SOC = previous_SOC + (Current * eta_charge) * (1/3600) / Capacity;
        else
            % Discharging (ideal case)
            SOC = previous_SOC + (Current * eta_discharge) * (1/3600) / Capacity;
        end
        
        % Bound SOC between [0,1]
        SOC = max(0, min(1, SOC));
        
        z = SOC;                % Save SOC for next iteration
    end
    
    % Output Y: Estimated SOC
    Y_est = SOC';               % Transpose for consistency
end
